# ClipRápido — proyecto web

## Qué hace
- Acepta enlaces de YouTube para preparar una vista previa con inicio y final.
- Permite subir un archivo de video propio/autorizado, recortarlo y descargarlo como MP4.
- El recorte se hace en el servidor con FFmpeg.

## Requisitos para publicarlo
- Node.js 18 o superior.
- FFmpeg instalado en el servidor y disponible como comando `ffmpeg`.
- Un hosting que permita ejecutar un servidor Node.js y procesar archivos (no basta con hosting estático).
- HTTPS recomendado.

## Ejecutar localmente
1. Instala Node.js y FFmpeg.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npm start`.
4. Abre `http://localhost:3000`.

## Publicación
Sube esta carpeta a un servicio de hosting que admita aplicaciones Node.js y FFmpeg. Configura el comando de inicio `npm start` y asegúrate de que FFmpeg esté instalado en el entorno. El proveedor debe permitir solicitudes POST y archivos de hasta 500 MB; algunos hostings tienen límites menores.

## Límites y uso
- Archivos máximos: 500 MB (el proveedor puede imponer un límite menor).
- Duración máxima de clip: 10 minutos.
- Formatos de entrada: MP4, WebM, MOV, MKV y AVI.
- La función de YouTube solo incrusta una vista previa; no descarga ni extrae el archivo de YouTube. Sube únicamente contenido propio o cuyo uso tengas autorizado.
- Para un sitio público real, añade autenticación, cuotas, protección contra abuso, límites de concurrencia y almacenamiento temporal gestionado. Este proyecto es una base funcional, no un servicio ya desplegado.
