const express = require("express");
const multer = require("multer");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_FILE = 500 * 1024 * 1024; // 500 MB
const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: MAX_FILE, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ok = /^video\/(mp4|webm|quicktime|x-matroska|x-msvideo)$/i.test(file.mimetype)
      || /\.(mp4|webm|mov|mkv|avi)$/i.test(file.originalname);
    cb(ok ? null : new Error("Formato no admitido. Usa MP4, WebM, MOV, MKV o AVI."), ok);
  }
});

app.use(express.static(path.join(__dirname, "public")));

function runFfmpeg(input, output, start, duration) {
  return new Promise((resolve, reject) => {
    const args = [
      "-hide_banner", "-loglevel", "error", "-y",
      "-ss", String(start), "-i", input,
      "-t", String(duration),
      "-map", "0:v:0?", "-map", "0:a:0?",
      "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
      "-c:a", "aac", "-b:a", "128k",
      "-movflags", "+faststart",
      output
    ];
    const proc = spawn("ffmpeg", args);
    let err = "";
    proc.stderr.on("data", d => err += d.toString());
    proc.on("error", reject);
    proc.on("close", code => code === 0 ? resolve() : reject(new Error(err || `FFmpeg terminó con código ${code}`)));
  });
}

app.post("/api/clip", upload.single("video"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Selecciona un archivo de video." });
  const start = Number(req.body.start);
  const end = Number(req.body.end);
  const input = req.file.path;
  const output = path.join(os.tmpdir(), `cliprapido-${crypto.randomBytes(8).toString("hex")}.mp4`);
  try {
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start) {
      return res.status(400).json({ error: "Los tiempos no son válidos. El final debe ser mayor que el inicio." });
    }
    if (end - start > 600) {
      return res.status(400).json({ error: "El clip no puede superar 10 minutos." });
    }
    await runFfmpeg(input, output, start, end - start);
    res.download(output, "cliprapido.mp4", err => {
      fs.rm(input, { force: true }, () => {});
      fs.rm(output, { force: true }, () => {});
      if (err && !res.headersSent) res.status(500).end("No se pudo enviar el clip.");
    });
  } catch (e) {
    fs.rm(input, { force: true }, () => {});
    fs.rm(output, { force: true }, () => {});
    if (!res.headersSent) res.status(500).json({ error: "No se pudo procesar el video. Comprueba que FFmpeg esté instalado y que el archivo sea válido." });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "El archivo supera el límite de 500 MB." });
  }
  res.status(400).json({ error: err.message || "Solicitud no válida." });
});

app.listen(PORT, () => console.log(`ClipRápido activo en el puerto ${PORT}`));
